#include "R61581.h"
#include "stm32f1xx_hal.h"
/* include for HAL_Delay */
void BUS_output(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  /*Configure GPIO pins : PB0 PB10 PB11 PB12
  PB8 PB9 */
  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LCD_BUS, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                            |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                       |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;

  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LCD_BUS, &GPIO_InitStruct);
}

void BUS_input(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  /*Configure GPIO pin Output Level */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                       |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;

  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(LCD_BUS, &GPIO_InitStruct);

  HAL_GPIO_WritePin(LCD_BUS, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                            |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);
}

void R61581WriteReg(uint16_t data)
{
  HAL_GPIO_WritePin(GPIOB, CTRL_RS_Pin,GPIO_PIN_RESET);
  WRITE_LCD(data&0xff);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, CTRL_RS_Pin,GPIO_PIN_SET);
}

void R61581Write8bit(uint8_t data)
{
  WRITE_LCD(data);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_SET);
}

void R61581WriteData(uint16_t data)
{
  WRITE_LCD(data>>8);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_SET);
  WRITE_LCD(data&0xff);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_SET);
}

uint16_t R61581ReadData(void)
{
  uint16_t data;
  BUS_input();
  HAL_GPIO_WritePin(GPIOB, CTRL_RS_Pin,GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, CTRL_WR_Pin,GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, CTRL_RD_Pin,GPIO_PIN_RESET);
  data=READ_LCD;
  HAL_GPIO_WritePin(GPIOB, CTRL_RD_Pin,GPIO_PIN_SET);
  BUS_output();
  return data;
}

void R61581DisplayOn()
{
  R61581WriteReg(0x29);
}

void R61581DisplayOff()
{
  R61581WriteReg(0x28);
}

void R61581MemoryWrite(unsigned short * pData, unsigned long size)
{
  unsigned long i;
  R61581WriteReg(0x2C);
  for(i=0;i<size;i++)
  {
    R61581WriteData(*pData++);
  }
}

void R61581RamAddress(void)
{
  // set column address
  R61581WriteReg(0x2a);
  R61581WriteData(0x00);
  R61581WriteData(0x00);
  R61581WriteData(0x01);
  R61581WriteData(0x3f);
  // set page address
  R61581WriteReg(0x2b);
  R61581WriteData(0x00);
  R61581WriteData(0x00);
  R61581WriteData(0x01);
  R61581WriteData(0xdf);
  // send command memory write
  R61581WriteReg(0x2c);
}

void R61581NormalDisplayModeOn()
{
  R61581WriteReg(0x13);
}

void R61581AllPixelOn()
{
  R61581WriteReg(0x23);
}

void R61581AllPixelOff()
{
  R61581WriteReg(0x22);
}

void R61581ColumnAddressSet(unsigned short SC, unsigned short EC)
{
  R61581WriteReg(0x2A);
  R61581WriteData( (SC & 0xFF00) >> 8);
  R61581WriteData(SC & 0xFF);
  R61581WriteData( (EC & 0xFF00) >> 8);
  R61581WriteData(EC & 0xFF);
}

void Ili9844PageAddressSet(unsigned short SP, unsigned short EP)
{
  R61581WriteReg(0x2B);
  R61581WriteData( (SP & 0xFF00) >> 8);
  R61581WriteData(SP & 0xFF);
  R61581WriteData( (EP & 0xFF00) >> 8);
  R61581WriteData(EP & 0xFF);
}

void R61581MemoryRead(unsigned short * pData, unsigned short size)
{
  unsigned short i;
  R61581WriteReg(0x2E);
  BUS_input();
  for(i=0;i<size;i++)
  {
    HAL_GPIO_WritePin(GPIOB, CTRL_RD_Pin,GPIO_PIN_RESET);
    *pData++ = READ_LCD;
    HAL_GPIO_WritePin(GPIOB, CTRL_RD_Pin,GPIO_PIN_SET);
  }
  BUS_output();
}

unsigned long R61581ReadDisplayStatus()
{
  volatile unsigned long tmp;
  R61581WriteReg(0x09);
  BUS_input();
  tmp=R61581ReadData()<<24;
  tmp=R61581ReadData()<<16;
  tmp=R61581ReadData()<<8;
  tmp=R61581ReadData();
  BUS_output();
  return tmp;
}

unsigned long R61581_ReadID(void)
{
  unsigned char buf[4];
  R61581WriteReg(0x04);
  BUS_input();
  buf[0] = R61581ReadData();
  buf[1] = R61581ReadData();
  buf[2] = R61581ReadData();
  buf[3] = R61581ReadData();
  BUS_output();
  return (buf[1]<<16)+(buf[2]<<8)+(buf[3]);
}

unsigned short R61581ReadNumberOfTheErrorsOnDsi()
{
  volatile unsigned short tmp;
  R61581WriteReg(0x05);
  BUS_input();
  HAL_GPIO_WritePin(GPIOB, CTRL_RD_Pin,GPIO_PIN_RESET);
  tmp = READ_LCD;
  HAL_GPIO_WritePin(GPIOB, CTRL_RD_Pin,GPIO_PIN_SET);
  BUS_output();
  return tmp;
}

