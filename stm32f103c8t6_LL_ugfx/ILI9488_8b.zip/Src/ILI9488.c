#include "ILI9488.h"
#include "main.h"

/* include for HAL_Delay */

void BUS_output(void)
{
  LL_GPIO_DeInit(GPIOA);
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  // LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOC);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);

  /**/
  LL_GPIO_ResetOutputPin(GPIOA, tft_data_Pin|tft_dataA1_Pin|tft_dataA2_Pin|tft_dataA3_Pin 
                          |tft_dataA4_Pin|tft_dataA5_Pin|tft_dataA6_Pin|tft_dataA7_Pin);

  /**/
  GPIO_InitStruct.Pin = tft_data_Pin|tft_dataA1_Pin|tft_dataA2_Pin|tft_dataA3_Pin 
                          |tft_dataA4_Pin|tft_dataA5_Pin|tft_dataA6_Pin|tft_dataA7_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void BUS_input(void)
{
  LL_GPIO_DeInit(GPIOA);
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  // LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOC);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_0|LL_GPIO_PIN_1|LL_GPIO_PIN_2|LL_GPIO_PIN_3 
                          |LL_GPIO_PIN_4|LL_GPIO_PIN_5|LL_GPIO_PIN_6|LL_GPIO_PIN_7;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_FLOATING;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void ILI9488WriteData8(uint8_t byte)
{
  //:! shift for accurate distribution, pins tft shield
  //:! A0 A1 A2 A3 A4 A5 A6 A7 GPIO stm32
  //:! D2 D3 D4 D5 D6 D7 D0 D1 display pins
  // BUS_output();
  uint8_t shift;
  shift=(byte >> 2) | (byte << 6);
  // GPIOA->ODR = byte;
  GPIOA->ODR = shift;
  // WRITE_LCD(byte);
  // WRITE_LCD(shift);

  pin_low(GPIOB, CTRL_WR_Pin);
  pin_high(GPIOB, CTRL_WR_Pin);
}

void ILI9488WriteReg(uint16_t data)
{
  pin_low(GPIOB, CTRL_RS_Pin);
  ILI9488WriteData8(data&0xff);
  pin_high(GPIOB, CTRL_RS_Pin);
}

void ILI9488WriteData(uint16_t data)
{
  ILI9488WriteData8(data>>8);
  ILI9488WriteData8(data&0xff);
}

uint16_t ILI9488ReadData(void)
{
  uint16_t data;
  BUS_input();
  pin_high(GPIOB, CTRL_RS_Pin);
  pin_high(GPIOB, CTRL_WR_Pin);
  pin_low(GPIOB, CTRL_RD_Pin);
  data=READ_LCD;
  pin_high(GPIOB, CTRL_RD_Pin);
  BUS_output();

  //return data;
  uint8_t shift;
  shift= ((data << 2) | (data >> 6));
  return shift;
}

void ILI9488DisplayOn()
{
  ILI9488WriteReg(0x29);
}

void ILI9488DisplayOff()
{
  ILI9488WriteReg(0x28);
}

void ILI9488MemoryWrite(unsigned short * pData, unsigned long size)
{
  unsigned long i;
  ILI9488WriteReg(0x2C);
  for(i=0;i<size;i++)
  {
    ILI9488WriteData(*pData++);
  }
}

void ILI9488RamAddress(void)
{
  // set column address
  ILI9488WriteReg(0x2a);
  ILI9488WriteData(0x00);
  ILI9488WriteData(0x00);
  ILI9488WriteData(0x01);
  ILI9488WriteData(0x3f);
  // set page address
  ILI9488WriteReg(0x2b);
  ILI9488WriteData(0x00);
  ILI9488WriteData(0x00);
  ILI9488WriteData(0x01);
  ILI9488WriteData(0xdf);
  // send command memory write
  ILI9488WriteReg(0x2c);
}

void ILI9488NormalDisplayModeOn()
{
  ILI9488WriteReg(0x13);
}

void ILI9488AllPixelOn()
{
  ILI9488WriteReg(0x23);
}

void ILI9488AllPixelOff()
{
  ILI9488WriteReg(0x22);
}

void ILI9488ColumnAddressSet(unsigned short SC, unsigned short EC)
{
  ILI9488WriteReg(0x2A);
  ILI9488WriteData( (SC & 0xFF00) >> 8);
  ILI9488WriteData(SC & 0xFF);
  ILI9488WriteData( (EC & 0xFF00) >> 8);
  ILI9488WriteData(EC & 0xFF);
}

void Ili9844PageAddressSet(unsigned short SP, unsigned short EP)
{
  ILI9488WriteReg(0x2B);
  ILI9488WriteData( (SP & 0xFF00) >> 8);
  ILI9488WriteData(SP & 0xFF);
  ILI9488WriteData( (EP & 0xFF00) >> 8);
  ILI9488WriteData(EP & 0xFF);
}

void ILI9488MemoryRead(unsigned short * pData, unsigned short size)
{
  unsigned short i;
  ILI9488WriteReg(0x2E);
  // BUS_input();
  for(i=0;i<size;i++)
  {
    pin_low(GPIOB, CTRL_RD_Pin);
    *pData++ = READ_LCD;
    pin_high(GPIOB, CTRL_RD_Pin);
  }
  // BUS_output();
}

unsigned long ILI9488ReadDisplayStatus()
{
  volatile unsigned long tmp;
  ILI9488WriteReg(0x09);
  // BUS_input();
  tmp=ILI9488ReadData()<<24;
  tmp=ILI9488ReadData()<<16;
  tmp=ILI9488ReadData()<<8;
  tmp=ILI9488ReadData();
  // BUS_output();
  return tmp;
}

unsigned long ILI9488_ReadID(void)
{
  unsigned char buf[4];
  ILI9488WriteReg(0x04);
  // BUS_input();
  buf[0] = ILI9488ReadData();
  buf[1] = ILI9488ReadData();
  buf[2] = ILI9488ReadData();
  buf[3] = ILI9488ReadData();
  // BUS_output();
  return (buf[1]<<16)+(buf[2]<<8)+(buf[3]);
}

unsigned short ILI9488ReadNumberOfTheErrorsOnDsi()
{
  volatile unsigned short tmp;
  ILI9488WriteReg(0x05);
  // BUS_input();
  pin_low(GPIOB, CTRL_RD_Pin);
  tmp = READ_LCD;
  pin_high(GPIOB, CTRL_RD_Pin);
  // BUS_output();
  return tmp;
}
