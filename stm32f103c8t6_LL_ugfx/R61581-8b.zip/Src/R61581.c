#include "R61581.h"
#include "main.h"

/* include for HAL_Delay */

void BUS_output(void)
{
  LL_GPIO_DeInit(GPIOA);
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  // LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOC);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);

  /**/
  LL_GPIO_ResetOutputPin(GPIOA, tft_data_Pin|tft_dataA1_Pin|tft_dataA2_Pin|tft_dataA3_Pin 
                          |tft_dataA4_Pin|tft_dataA5_Pin|tft_dataA6_Pin|tft_dataA7_Pin);

  /**/
  GPIO_InitStruct.Pin = tft_data_Pin|tft_dataA1_Pin|tft_dataA2_Pin|tft_dataA3_Pin 
                          |tft_dataA4_Pin|tft_dataA5_Pin|tft_dataA6_Pin|tft_dataA7_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void BUS_input(void)
{
  LL_GPIO_DeInit(GPIOA);
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  // LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOC);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_0|LL_GPIO_PIN_1|LL_GPIO_PIN_2|LL_GPIO_PIN_3 
                          |LL_GPIO_PIN_4|LL_GPIO_PIN_5|LL_GPIO_PIN_6|LL_GPIO_PIN_7;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_FLOATING;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void R61581WriteData8(uint8_t byte)
{
  //:! shift for accurate distribution, pins tft shield
  //:! A0 A1 A2 A3 A4 A5 A6 A7 GPIO stm32
  //:! D2 D3 D4 D5 D6 D7 D0 D1 display pins
  // BUS_output();
  uint8_t shift;
  shift=(byte >> 2) | (byte << 6);
  // GPIOA->ODR = byte;
  GPIOA->ODR = shift;
  // WRITE_LCD(byte);
  // WRITE_LCD(shift);

  pin_low(GPIOB, CTRL_WR_Pin);
  pin_high(GPIOB, CTRL_WR_Pin);
}

void R61581WriteReg(uint16_t data)
{
  pin_low(GPIOB, CTRL_RS_Pin);
  R61581WriteData8(data&0xff);
  pin_high(GPIOB, CTRL_RS_Pin);
}

void R61581WriteData(uint16_t data)
{
  R61581WriteData8(data>>8);
  R61581WriteData8(data&0xff);
}

uint16_t R61581ReadData(void)
{
  uint16_t data;
  BUS_input();
  pin_high(GPIOB, CTRL_RS_Pin);
  pin_high(GPIOB, CTRL_WR_Pin);
  pin_low(GPIOB, CTRL_RD_Pin);
  data=READ_LCD;
  pin_high(GPIOB, CTRL_RD_Pin);
  BUS_output();

  //return data;
  uint8_t shift;
  shift= ((data << 2) | (data >> 6));
  return shift;
}

void R61581DisplayOn()
{
  R61581WriteReg(0x29);
}

void R61581DisplayOff()
{
  R61581WriteReg(0x28);
}

void R61581MemoryWrite(unsigned short * pData, unsigned long size)
{
  unsigned long i;
  R61581WriteReg(0x2C);
  for(i=0;i<size;i++)
  {
    R61581WriteData(*pData++);
  }
}

void R61581RamAddress(void)
{
  // set column address
  R61581WriteReg(0x2a);
  R61581WriteData(0x00);
  R61581WriteData(0x00);
  R61581WriteData(0x01);
  R61581WriteData(0x3f);
  // set page address
  R61581WriteReg(0x2b);
  R61581WriteData(0x00);
  R61581WriteData(0x00);
  R61581WriteData(0x01);
  R61581WriteData(0xdf);
  // send command memory write
  R61581WriteReg(0x2c);
}

void R61581NormalDisplayModeOn()
{
  R61581WriteReg(0x13);
}

void R61581AllPixelOn()
{
  R61581WriteReg(0x23);
}

void R61581AllPixelOff()
{
  R61581WriteReg(0x22);
}

void R61581ColumnAddressSet(unsigned short SC, unsigned short EC)
{
  R61581WriteReg(0x2A);
  R61581WriteData( (SC & 0xFF00) >> 8);
  R61581WriteData(SC & 0xFF);
  R61581WriteData( (EC & 0xFF00) >> 8);
  R61581WriteData(EC & 0xFF);
}

void Ili9844PageAddressSet(unsigned short SP, unsigned short EP)
{
  R61581WriteReg(0x2B);
  R61581WriteData( (SP & 0xFF00) >> 8);
  R61581WriteData(SP & 0xFF);
  R61581WriteData( (EP & 0xFF00) >> 8);
  R61581WriteData(EP & 0xFF);
}

void R61581MemoryRead(unsigned short * pData, unsigned short size)
{
  unsigned short i;
  R61581WriteReg(0x2E);
  // BUS_input();
  for(i=0;i<size;i++)
  {
    pin_low(GPIOB, CTRL_RD_Pin);
    *pData++ = READ_LCD;
    pin_high(GPIOB, CTRL_RD_Pin);
  }
  // BUS_output();
}

unsigned long R61581ReadDisplayStatus()
{
  volatile unsigned long tmp;
  R61581WriteReg(0x09);
  // BUS_input();
  tmp=R61581ReadData()<<24;
  tmp=R61581ReadData()<<16;
  tmp=R61581ReadData()<<8;
  tmp=R61581ReadData();
  // BUS_output();
  return tmp;
}

unsigned long R61581_ReadID(void)
{
  unsigned char buf[4];
  R61581WriteReg(0x04);
  // BUS_input();
  buf[0] = R61581ReadData();
  buf[1] = R61581ReadData();
  buf[2] = R61581ReadData();
  buf[3] = R61581ReadData();
  // BUS_output();
  return (buf[1]<<16)+(buf[2]<<8)+(buf[3]);
}

unsigned short R61581ReadNumberOfTheErrorsOnDsi()
{
  volatile unsigned short tmp;
  R61581WriteReg(0x05);
  // BUS_input();
  pin_low(GPIOB, CTRL_RD_Pin);
  tmp = READ_LCD;
  pin_high(GPIOB, CTRL_RD_Pin);
  // BUS_output();
  return tmp;
}
