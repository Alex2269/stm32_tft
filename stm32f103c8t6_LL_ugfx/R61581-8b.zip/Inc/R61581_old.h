#ifndef _R61581_H
#define _R61581_H

//GPIOA first 8 pins for data
//this pin is called rs on my dev board
// A0 A1 A2 A3 A4 A5 A6 A7 STM32 GPIOA
// D0 D1 D2 D3 D4 D5 D6 D7 TFT   DATA PORT

#define LCD_BUS GPIOA
#define WRITE_LCD(data) LCD_BUS->BSRR = (LCD_BUS->BSRR & 0xff00ff00) | (uint32_t)(((0x00ff & ~data) << 16u)| (0x00ff & data));
#define READ_LCD (LCD_BUS->IDR & 0b0000000011111111)

void BUS_output(void);
void BUS_input(void);
void R61581DisplayOn(void);
void R61581DisplayOff(void);
void R61581NormalDisplayModeOn(void);
unsigned long R61581_ReadID(void);
unsigned long R61581ReadDisplayStatus(void);
void R61581AllPixelOn(void);
void R61581AllPixelOff(void);

void R61581_Initial_Code(void);
void R61581MemoryRead(unsigned short * pData, unsigned short size);
void R61581WriteReg(uint16_t data) ;
void R61581WriteData(uint16_t data) ;
void R61581Write8bit(uint8_t data);
uint16_t R61581ReadData(void) ;

#endif
