#ifndef _R61581_H
#define _R61581_H

#include "stm32f1xx_ll_gpio.h"
#include "stm32f1xx_ll_bus.h"

//:! GPIOA first 8 pins for data
//:! this pin is called rs on my dev board
//:! A0 A1 A2 A3 A4 A5 A6 A7 STM32 GPIOA
//:! D0 D1 D2 D3 D4 D5 D6 D7 TFT   DATA PORT

//:! for remaping pins see: R61581.c func R61581WriteData8
//:! shift for accurate distribution, pins tft shield
//:! A0 A1 A2 A3 A4 A5 A6 A7 GPIO stm32
//:! D2 D3 D4 D5 D6 D7 D0 D1 display pins

#define LCD_BUS GPIOA
#define WRITE_LCD(data) LCD_BUS->BSRR = (LCD_BUS->BSRR & 0xff00ff00) | (uint32_t)(((0x00ff & ~data) << 16u)| (0x00ff & data));
#define READ_LCD (LCD_BUS->IDR & 0b0000000011111111)

/* Declare Private Macro */
// #define		pin_low(port,pin)	HAL_GPIO_WritePin(port,pin,GPIO_PIN_RESET)

__STATIC_INLINE void pin_low(GPIO_TypeDef *GPIOx, uint32_t PinMask)
{
  WRITE_REG(GPIOx->BRR, (PinMask >> GPIO_PIN_MASK_POS) & 0x0000FFFFU);
}

__STATIC_INLINE void pin_high(GPIO_TypeDef *GPIOx, uint32_t PinMask)
{
  WRITE_REG(GPIOx->BSRR, (PinMask >> GPIO_PIN_MASK_POS) & 0x0000FFFFU);
}

// #define		pin_high(port,pin)	HAL_GPIO_WritePin(port,pin,GPIO_PIN_SET)

void BUS_output(void);
void BUS_input(void);
void R61581DisplayOn(void);
void R61581DisplayOff(void);
void R61581NormalDisplayModeOn(void);
unsigned long R61581_ReadID(void);
unsigned long R61581ReadDisplayStatus(void);
void R61581AllPixelOn(void);
void R61581AllPixelOff(void);

void R61581_Initial_Code(void);
void R61581MemoryRead(unsigned short * pData, unsigned short size);
void R61581WriteReg(uint16_t data) ;
void R61581WriteData(uint16_t data) ;
void R61581WriteData8(uint8_t data);
uint16_t R61581ReadData(void) ;

#endif
