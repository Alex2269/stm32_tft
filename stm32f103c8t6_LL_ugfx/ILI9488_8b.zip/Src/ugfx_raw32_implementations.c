#include "stm32f1xx_ll_cortex.h"
#include "time.h"
#include "gfx.h"

void raw32Init(void)
{
  // handled by hal
  (SysTick_Config(SystemCoreClock / 1000));
}

systemticks_t gfxSystemTicks(void)
{
  // We use a counter with a 1kHz clock source
  // return LL_SYSTICK_GetClkSource(); // HAL_GetTick();
  // get_time_reload();
  return SysTick->VAL;
}
 
systemticks_t gfxMillisecondsToTicks(delaytime_t ms)
{
  // We use a counter with a 1kHz clock source
  return ms;
}

void SleepMilliseconds(delaytime_t ms)
{
  systemticks_t currenttm, starttm;
  starttm = gfxSystemTicks();
  do
  {
    currenttm = gfxSystemTicks(); 
  }
  while
  (currenttm - starttm < ms);
}
